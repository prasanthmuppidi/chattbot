for running chatterbot1
python "app.py"

for running app first delete
db.sqlite3
db.sqlite3-shm
db.sqlite3-wal
every time

pip install Chatterbot==1.0.0